#include "main.h"
/**
 * add - add two given numbers
 *
 *@number1: first number given
 *@number2: second number given
 *
 * Return: The sum of two numbers
 */
int add(int number1, int number2)
{
	return (number1 + number2);
}
