#include "main.h"
#include <string.h>
/**
 * _strcpy - copy the string
 * @dest: destination string
 * @src: the source string wichin is to be copied
 * Return: a copied cahracter
 */
char *_strcpy(char *dest, char *src)
{
	strcpy(dest, src);
	return (dest);
}
