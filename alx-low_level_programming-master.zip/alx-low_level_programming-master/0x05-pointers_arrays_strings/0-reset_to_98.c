#include "main.h"
/**
 *reset_to_98 - modifies the value
 *of a number.
 *@n :pointer to the number
 */
void reset_to_98(int *n)
{
	*n = 98;
}

