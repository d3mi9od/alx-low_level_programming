Lily for dayz
