#include "main.h"
/**
* mul - multiply two numbers
*
*@a : first number
*@b : second number
*
*Return: result of a * b
*/
int mul(int a, int b)
{
	int result = a * b;

	return (result);
}
