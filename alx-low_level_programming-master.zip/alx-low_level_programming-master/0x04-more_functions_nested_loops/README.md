There's nothing more truely artistic than coding.
