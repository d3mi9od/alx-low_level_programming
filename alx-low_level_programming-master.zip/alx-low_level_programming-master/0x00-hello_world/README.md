C is fan
